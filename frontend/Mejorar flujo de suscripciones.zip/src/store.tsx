import { createContext, useCallback, useContext, useMemo, useReducer, type ReactNode } from 'react'
import {
  nowLabel,
  seedPayments,
  seedPlans,
  seedSubscribers,
  type Payment,
  type PaymentMethod,
  type Plan,
  type Subscriber,
} from './data'

type State = { plans: Plan[]; subscribers: Subscriber[]; payments: Payment[] }

type Action =
  | { type: 'savePlan'; plan: Plan }
  | { type: 'addSubscriber'; subscriber: Subscriber }
  | { type: 'requestPayment'; payment: Payment }
  | { type: 'confirmPayment'; paymentId: string }
  | { type: 'payCash'; payment: Payment }

const markPaid = (subs: Subscriber[], id: string) =>
  subs.map((s) => (s.id === id ? { ...s, status: 'al_corriente' as const, note: 'Pagó hoy' } : s))

function reducer(state: State, action: Action): State {
  switch (action.type) {
    case 'savePlan': {
      const exists = state.plans.some((p) => p.id === action.plan.id)
      return {
        ...state,
        plans: exists ? state.plans.map((p) => (p.id === action.plan.id ? action.plan : p)) : [...state.plans, action.plan],
      }
    }
    case 'addSubscriber':
      return { ...state, subscribers: [...state.subscribers, action.subscriber] }
    case 'requestPayment':
      return { ...state, payments: [action.payment, ...state.payments] }
    case 'confirmPayment': {
      const payment = state.payments.find((p) => p.id === action.paymentId)
      if (!payment || payment.status === 'pagado') return state
      return {
        ...state,
        payments: state.payments.map((p) =>
          p.id === action.paymentId ? { ...p, status: 'pagado', when: nowLabel() } : p,
        ),
        subscribers: markPaid(state.subscribers, payment.subscriberId),
      }
    }
    case 'payCash':
      return {
        ...state,
        payments: [action.payment, ...state.payments],
        subscribers: markPaid(state.subscribers, action.payment.subscriberId),
      }
  }
}

export type PlanStats = {
  plan: Plan
  subs: Subscriber[]
  expected: number
  collected: number
  pending: number
  late: number
}

function useStoreValue() {
  const [state, dispatch] = useReducer(reducer, {
    plans: seedPlans,
    subscribers: seedSubscribers,
    payments: seedPayments,
  })

  const derived = useMemo(() => {
    const planStats: PlanStats[] = state.plans.map((plan) => {
      const subs = state.subscribers.filter((s) => s.planId === plan.id)
      const paid = subs.filter((s) => s.status === 'al_corriente').length
      return {
        plan,
        subs,
        expected: subs.length * plan.price,
        collected: paid * plan.price,
        pending: (subs.length - paid) * plan.price,
        late: subs.filter((s) => s.status === 'atrasado').length,
      }
    })
    const expected = planStats.reduce((a, p) => a + p.expected, 0)
    const collected = planStats.reduce((a, p) => a + p.collected, 0)
    const lateSubs = state.subscribers.filter((s) => s.status === 'atrasado')
    const lateAmount = lateSubs.reduce((a, s) => a + (state.plans.find((p) => p.id === s.planId)?.price ?? 0), 0)
    const paidCount = state.subscribers.filter((s) => s.status === 'al_corriente').length
    return { planStats, expected, collected, pending: expected - collected, lateSubs, lateAmount, paidCount }
  }, [state])

  const api = useMemo(
    () => ({
      plan: (id: string) => state.plans.find((p) => p.id === id),
      subscriber: (id: string) => state.subscribers.find((s) => s.id === id),
      payment: (id: string) => state.payments.find((p) => p.id === id),
      savePlan: (plan: Plan) => dispatch({ type: 'savePlan', plan }),
      addSubscriber: (subscriber: Subscriber) => dispatch({ type: 'addSubscriber', subscriber }),
      startPayment: (subscriberId: string, method: PaymentMethod) => {
        const sub = state.subscribers.find((s) => s.id === subscriberId)
        const plan = sub && state.plans.find((p) => p.id === sub.planId)
        if (!sub || !plan) return null
        const payment: Payment = {
          id: `p${Date.now()}`,
          subscriberId,
          planId: plan.id,
          amount: plan.price,
          method,
          status: method === 'efectivo' ? 'pagado' : 'pendiente',
          when: nowLabel(),
        }
        dispatch(method === 'efectivo' ? { type: 'payCash', payment } : { type: 'requestPayment', payment })
        return payment.id
      },
    }),
    [state],
  )

  // Estable entre renders: la pantalla del QR la usa dentro de un temporizador.
  const confirmPayment = useCallback((paymentId: string) => dispatch({ type: 'confirmPayment', paymentId }), [])

  return { ...state, ...derived, ...api, confirmPayment }
}

type Store = ReturnType<typeof useStoreValue>
const StoreContext = createContext<Store | null>(null)

export function StoreProvider({ children }: { children: ReactNode }) {
  const value = useStoreValue()
  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>
}

export function useStore() {
  const store = useContext(StoreContext)
  if (!store) throw new Error('useStore fuera de StoreProvider')
  return store
}
